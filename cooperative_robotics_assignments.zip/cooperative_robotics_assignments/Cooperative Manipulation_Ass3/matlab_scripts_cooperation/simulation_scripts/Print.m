function Print(array, str)
    % To print the arrays
    fprintf('%s', str);  % Stampa la stringa
    fprintf('%g ', array);   % Stampa gli elementi dell'array separati da uno spazio
    fprintf('\n');           % Vai a capo
end